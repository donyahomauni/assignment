package builder;

import model.Student;

public class StudentBuilder {

    private String username;
    private String fullName;
    private String password;
    private Integer age;
    private String address;
    private String phoneNo;
    private String degree;

    public StudentBuilder(String username, String fullName, String password,
                          Integer age, String address, String phoneNo, String degree) {
        this.username = username;
        this.fullName = fullName;
        this.password = password;
        this.age = age;
        this.address = address;
        this.phoneNo = phoneNo;
        this.degree = degree;
    }

    public StudentBuilder(){}

    public StudentBuilder setUsername(String username) {
        this.username = username;
        return this;
    }

    public StudentBuilder setFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    public StudentBuilder setPassword(String password) {
        this.password = password;
        return this;
    }

    public StudentBuilder setAge(Integer age) {
        this.age = age;
        return this;
    }

    public StudentBuilder setAddress(String address) {
        this.address = address;
        return this;
    }

    public StudentBuilder setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
        return this;
    }

    public StudentBuilder setDegree(String degree) {
        this.degree = degree;
        return this;
    }

    public Student build(){
        return new Student(username , fullName , password , age , address , phoneNo , degree);
    }
}
