package main;

import factory.Factory;
import model.Car;

public class Main {
    public static void main(String[] args) {
        Factory factory = new Factory();

        Car bmw = factory.createCar("BMW");
        Car benz = factory.createCar("Benz");

        System.out.println(String.join(" " , bmw.getManufacturer() , bmw.getPower().toString()));
        System.out.println(String.join(" " , benz.getManufacturer() , benz.getPower().toString()));
    }
}
