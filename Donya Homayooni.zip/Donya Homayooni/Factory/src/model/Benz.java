package model;

public class Benz extends Car{
}
