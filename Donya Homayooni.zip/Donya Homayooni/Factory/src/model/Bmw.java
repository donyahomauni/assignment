package model;

public class Bmw extends Car{
}
